import { Component, OnInit } from '@angular/core';
import { ServerService} from '../server.service';
import { Journal } from './resultsG.model';
import { InputFieldComponent} from '../input-field/input-field.component';


@Component({
  selector: 'app-results',
  templateUrl: './resultsG.component.html',
  styleUrls: ['./resultsG.component.css']
})
export class ResultsGComponent  implements OnInit {
  public values: any[];
  public title: string;
  public abstract: string;
  journals: Journal []


  constructor(private serverService: ServerService) {}
  ngOnInit() {}
  onSubmit(form) {
    this.title = form.value['title'], this.abstract = form.value['abstract'];
    this.serverService.findJournals(this.title, this.abstract)
        .subscribe( data => { console.log(data); this.values = data ['journals'] ; },
            // (response) => console.log(response),
            (error) => console.log(error)
        );

    this.journals = this.values;
  }
}


    /*
    this.serverService.findJournals(this.title, this.abstract)
        .subscribe( data => { console.log(data); this.values = data ['journals'] ; },
            // (response) => console.log(response),
            (error) => console.log(error)
        );
        */




