export class Journal {
    public name: string;
    public description: string;
    public other: string;

    constructor(name: string, description: string, other: string) {
        this.name = name;
        this.description = description;
        this.other = other;
    }
}




